//
// Created by Matheus Freitas on 24/09/2023.
//

#ifndef BIBLIOTECA_H
#define BIBLIOTECA_H

typedef struct {
    int prioridade;
    char descricao[300];
    char categoria[100];
} Tarefa;

void limparBuffer();
void cadastrarTarefa(Tarefa *tarefas, int *numTarefas);
void listarTarefas(const Tarefa *tarefas, int numTarefas);
void deletarTarefa(Tarefa *tarefas, int *numTarefas);
void salvarTarefas(const char *filename, const Tarefa *tarefas, int numTarefas);
void carregarTarefas(const char *filename, Tarefa *tarefas, int *numTarefas);

#endif //BIBLIOTECA_H
