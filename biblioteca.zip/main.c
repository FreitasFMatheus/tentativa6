
#include "biblioteca.h"
#include <stdio.h>

int main() {
    int opcao;
    int numTarefas = 0;
    Tarefa tarefas[100];

    do {
        printf("1. Cadastrar Tarefa\n");
        printf("2. Listar Tarefas\n");
        printf("3. Deletar Tarefa\n");
        printf("4. Salvar Tarefas\n");
        printf("5. Carregar Tarefas\n");
        printf("0. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch(opcao) {
            case 1:
                cadastrarTarefa(tarefas, &numTarefas);
                break;
            case 2:
                listarTarefas(tarefas, numTarefas);
                break;
            case 3:
                deletarTarefa(tarefas, &numTarefas);
                break;
            case 4:
                salvarTarefas("tarefas.dat", tarefas, numTarefas);
                break;
            case 5:
                carregarTarefas("tarefas.dat", tarefas, &numTarefas);
                break;
        }
    } while(opcao != 0);

    return 0;
}
