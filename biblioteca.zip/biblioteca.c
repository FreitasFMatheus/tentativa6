//
// Created by Matheus Freitas on 24/09/2023.
//
#include "biblioteca.h"
#include <stdio.h>

void limparBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {}
}

void cadastrarTarefa(Tarefa *tarefas, int *numTarefas) {
    if(*numTarefas >= 100) {
        printf("Não é possível cadastrar mais tarefas!\n");
        return;
    }

    Tarefa novaTarefa;
    limparBuffer();
    printf("Descrição: ");
    fgets(novaTarefa.descricao, 299, stdin);
    printf("Categoria: ");
    fgets(novaTarefa.categoria, 99, stdin);
    printf("Prioridade: ");
    scanf("%d", &novaTarefa.prioridade);

    tarefas[*numTarefas] = novaTarefa;
    (*numTarefas)++;
}

void listarTarefas(const Tarefa *tarefas, int numTarefas) {
    for(int i = 0; i < numTarefas; i++) {
        printf("%d - %s, %s, %d\n", i, tarefas[i].descricao, tarefas[i].categoria, tarefas[i].prioridade);
    }
}

void deletarTarefa(Tarefa *tarefas, int *numTarefas) {
    int index;
    printf("Indique o índice da tarefa a ser deletada: ");
    scanf("%d", &index);

    if(index < 0 || index >= *numTarefas) {
        printf("Índice inválido!\n");
        return;
    }

    for(int i = index; i < *numTarefas - 1; i++) {
        tarefas[i] = tarefas[i + 1];
    }

    (*numTarefas)--;
}

void salvarTarefas(const char *filename, const Tarefa *tarefas, int numTarefas) {
    FILE *file = fopen(filename, "wb");
    if (!file) {
        perror("Erro ao abrir o arquivo");
        return;
    }
    fwrite(&numTarefas, sizeof(int), 1, file);
    fwrite(tarefas, sizeof(Tarefa), numTarefas, file);
    fclose(file);
}

void carregarTarefas(const char *filename, Tarefa *tarefas, int *numTarefas) {
    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Erro ao abrir o arquivo");
        return;
    }
    fread(numTarefas, sizeof(int), 1, file);
    fread(tarefas, sizeof(Tarefa), *numTarefas, file);
    fclose(file);
}
